# unity-hello-world
Первый проект на Unity + GitHub
